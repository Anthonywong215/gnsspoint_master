---
name: Bug report
about: Report an import, conversion, map or export problem
title: ""
labels: bug
---

## What happened?

Describe the observed behavior and the expected result.

## Reproduce

1. Browser / operating system:
2. Input angle format and output order:
3. Small synthetic input or steps:
4. Error message, if any:

## Export details

Which download was affected: Results CSV, TXYZ TXT, Measurements CSV, Point stats CSV or JSON?
