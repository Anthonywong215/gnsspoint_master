# GNSS → HK1980 coordinate converter

**By Anthony Wong · Version 1.1.0**

A local website for preparing GNSS exports, converting individual WGS84 readings with the Hong Kong Lands Department API, and exporting one mean coordinate per unique survey point for CAD.

**WGS84 latitude / longitude + ellipsoidal height → HK80 Easting / Northing + height in mPD.**

![Synthetic demonstration of the converter](docs/images/overview.png)

## Quick start

1. Extract the release ZIP and keep its folders together.
2. Use [Node.js](https://nodejs.org/) 22 or later. No package installation or build is needed.
3. On Windows, double-click **start.cmd**. Elsewhere, run `npm start` from this folder and open [the local website](http://127.0.0.1:8080).
4. Drag in TXT, CSV or TSV exports. Try [samples/demo_decimal.txt](samples/demo_decimal.txt): six synthetic readings of two unique points.
5. Click **Convert with LandsD**, then download **Results CSV** or **TXYZ TXT** in **Unique point means**.

Read the [user guide](docs/USER_GUIDE.md), or open the [printable HTML guide](docs/USER_GUIDE.html) in a browser. Opening `index.html` directly supports import, conversion and point overlays; use the launcher for the OSM background.

### Paste HK1980 points onto the map

Select **Paste N,E,Z**, type or paste one `Name,Northing,Easting,Z` row per line, then click **Load & zoom to points**. You can also drop a TXT/CSV/TSV file into the writable text box. The optional header is `Name,N,E,Z`; Northing comes before Easting. Commas, tabs, spaces and semicolons are supported. Try [samples/demo_nez.txt](samples/demo_nez.txt).

```text
Name,N,E,Z
P1,820358.910,832590.508,26.009
P2,820458.910,832690.508,27.000
```

These inputs are **HK1980 Grid coordinates in metres**, with Z retained in mPD. LandsD converts N/E to WGS84 map positions; Z is kept as entered. Internet access is required. Pasted points appear in blue alongside green GNSS readings. Loading replaces the previous pasted set and zooms to that set; **Fit all points** includes both. Invalid rows or failed/stopped lookups keep the previous set in place. The separate **Clear pasted points** button removes only the pasted set. GNSS conversion downloads and mean calculations continue to use receiver readings only.

### Using a Git clone

Launch `start.cmd` or `npm start` from the repository root. Keep `vendor/leaflet/` beside the root `index.html`: it supplies the local map script and stylesheet. The `docs/`, `samples/`, `scripts/` and `tests/` folders also belong at that root. The `web_point_convert_visual/` copy includes the same Topcon/Sino import support and can also be launched from its own folder. The repository root is the main source for future edits.

The supported Topcon/Sino layout uses **Name, B, L, 84H**. Both website copies keep the same height checks, original measurement IDs and collection-time playback. See [GitHub Desktop instructions](docs/GITHUB_SHARING.md#commit-with-github-desktop) to commit local changes.

If the map library is missing, no OSM tile requests can start. Run `npm test` to check that the page assets exist and that Leaflet/converter load before the map/application scripts. Open the app through its local web address for OSM background tiles; direct `file://` mode shows observation overlays without requesting tiles.

## Downloads

| Download         | Contents                                                                                                                                   |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| Results CSV      | Exactly `ID,Easting,Northing,mPD`; one mean row per fully converted unique point. Northing-first exports `ID,Northing,Easting,mPD`.        |
| TXYZ TXT         | `coordinate.txt`: the same unique means and IDs without a header or BOM. Default `ID,Easting,Northing,mPD` (TXYZ); Northing-first is TYXZ. |
| Measurements CSV | Every accepted reading, original/group/record IDs, source file/row, time, individual conversion results and errors.                        |
| Point stats CSV  | Counts, mean, sample SD, min/max and range per unique point; includes partial conversion counts.                                           |
| JSON             | Individual measurement data, named coordinate fields and provenance.                                                                       |
| Prepared CSV     | Four input fields: point name, normalized latitude, longitude and elevation.                                                               |

Example Results CSV:

```csv
ID,Easting,Northing,mPD
SC43,832590.508,820358.910,26.009
```

Equivalent headerless `coordinate.txt`:

```text
SC43,832590.508,820358.910,26.009
```

Means are calculated from individual LandsD results, then rounded to three decimal places. A point enters the four-column CAD exports only when **all its accepted readings have converted**. Incomplete groups remain in the detailed measurement/statistics exports; the interface shows the ready/incomplete counts.

## Features

- Multiple-file drag and drop; comma/tab/semicolon separators and quoted fields.
- Decimal/DMS checks and normalization; ambiguous packed DMS requires explicit selection.
- Hong Kong range checks, source-line errors and height-datum reminders.
- `SC43.1`, `.2`, `.3` collapse under point ID `SC43`; all measurements remain available.
- Unique point/measurement counts and converted mean/sample SD/min/max/range.
- OSM mini map, bounding rectangle and chronological playback with recorded times and delay control.
- Small, Medium, Large and Full screen map controls; hover over GNSS or pasted points in Large/Full screen to read their names.
- EN/NE switching without reconversion; EN defaults to MicroStation TXYZ order.
- Responsive layout, larger type and keyboard controls.

Receiver layouts are detected from column headings; column order is flexible:

| Layout | Point name | Latitude | Longitude | WGS84 ellipsoidal height | Collection time |
| --- | --- | --- | --- | --- | --- |
| Standard export | Point name | Latitude | Longitude | Elevation | Date + Time (optional) |
| Topcon export | Name | B | L | 84H | Start time (optional), e.g. `2026/10/16 09:32:30` |

**Topcon's Elevation column is ignored; height comes only from 84H.** Existing E/N/Z and a standard export's separate Height are also ignored. Missing or ambiguous required headings are rejected. The file list shows the detected mapping. Topcon timestamps drive chronological playback across files; the original timestamp is retained in Measurements CSV/JSON. Invalid or missing timestamps use the existing import-order playback fallback.

Topcon readings retain their full decimal precision. `2098.010.1` and `2098.010.2` group under **2098.010**, and duplicate names remain separate readings with separate Record IDs. Try [samples/demo_topcon.txt](samples/demo_topcon.txt) for a synthetic example. Both receiver layouts can be imported together. Confirm the source datum; coordinate values alone cannot establish it.

## Data and services

Files and point names remain in the browser. OSM serves background tiles for the viewed area. Convert sends latitude, longitude and height to LandsD; a reading's Open link also requests conversion. State lasts for the current page session, so download before refreshing or closing.

The [official LandsD manual, Example 3](https://www.geodetic.gov.hk/transform/v2/tformAPI_manual.pdf#page=9) supplies the built-in reference check. Leaflet 1.9.4 and its BSD license are bundled; see [third-party notices](THIRD_PARTY_NOTICES.md).

## Development and sharing

```text
npm test
npm run test:live
npm run package
```

Offline tests need no network. The optional live check verifies the public LandsD reference response. Packaging writes a ZIP, SHA-256 checksum and manifest into `release/`. GitHub Actions checks Node.js 22 and 24. The source also works on a static host with relative asset paths.

See [CONTRIBUTING.md](CONTRIBUTING.md), [GitHub sharing](docs/GITHUB_SHARING.md) and [CHANGELOG.md](CHANGELOG.md). Release archives contain synthetic examples, not original field exports or generated survey results. The package does not choose a license for Anthony Wong's original application code.
